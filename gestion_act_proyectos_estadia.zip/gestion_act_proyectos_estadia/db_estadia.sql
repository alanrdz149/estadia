create database registrosSistemas

go

use registrosSistemas

create table metricas(
id_metrica int IDENTITY(1,1) primary key not null,
metrica varchar(10) not null
)

create table estatus(
id_estatus int IDENTITY(1,1) primary key not null,
estatus varchar(20) not null
)

create table areas(
id_areas int IDENTITY(1,1) primary key not null,
area varchar(10) not null,
)

create table periodos(
id_periodos int IDENTITY(1,1) primary key not null,
periodo varchar(15) not null
)

create table usuarios(
id_usuario int IDENTITY(1,1) primary key not null,
nombre_usuario varchar(60) not null
)

create table  actividades(
id_actividad int IDENTITY(1,1) primary key not null,
actividad varchar(30) not null,
metrica_id int not null,
constraint fk_metrica foreign key(metrica_id)
references metricas(id_metrica)
)

create table semanas(
semana_id int IDENTITY(1,1) primary key not null,
semana int not null, 
periodo_id int not null,
constraint fk_periodo foreign key (periodo_id)
references periodos(id_periodos)
)

create table activiades_usuarios(
id_actUsr int IDENTITY(1,1) primary key not null,
act_estimadas int not null,
act_reales int not null,
actividades_id int not null,
usuarios_id int not null,
semanas_id int not null,
constraint fk_actividades foreign key(actividades_id)
references actividades(id_actividad),
constraint fk_usuarios foreign key(usuarios_id)
references usuarios(id_usuario),
constraint fk_semanas foreign key(semanas_id)
references semanas(semana_id)
)

create table proyectos(
proyecto_id int IDENTITY(1,1) primary key not null,
nombre varchar(50) not null,
descripcion varchar(100) not null,
fecha_inicio date not null,
dias_estimados int not null,
dias_reales int not null,
fecha_fin date not null,
area_id int not null,
usuario_id int not null,
periodos_id int not null,
estatus_id int not null,
constraint fk_area foreign key(area_id)
references areas(id_areas),
constraint fk_usuario foreign key(usuario_id)
references usuarios(id_usuario),
constraint fk_periodos foreign key(periodos_id)
references periodos(id_periodos),
constraint fk_estatus foreign key(estatus_id)
references estatus(id_estatus)
)