<?php include('./database/db.php'); ?>
<?php include('./database/area/obtener_areas.php'); ?>
<?php include('./database/estatus/mostrar_estatus.php'); ?>
<?php include('./database/usuarios/obtener_usuarios.php'); ?>
<?php include('./database/proyectos/mostrar_proyectos.php'); ?>
<?php include('./database/periodo/obtener_periodo.php'); ?>
<?php include('includes/header.php'); ?>
<main class="container-fluid">
  <?php if (isset($_SESSION['message'])) { ?>
    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message'] ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php session_unset();
  } ?>
  <div class="row  p-5">
    <div class="card card-body ml-5 mr-5">
      <h1>Proyectos</h1>
      <form action="./database/proyectos/guardar_proyecto.php" method="POST">
        <div class="form-group">
          <input type="text" name="nombre" class="form-control " placeholder="Ingrese el nombre del proyecto que desea registrar" autofocus>
          <input type="text" name="desc" class="form-control mt-3" placeholder="Ingrese una breve descripción">
          <select name="responsable" class="form-control mt-3" required>
            <option value="">Responsable(s) del proyecto</option>
            <?php
            foreach (getAllUsuarios() as $u) { ?>
              <option value="<?= $u['0'] ?>"><?= $u['1'] ?> </option>
            <?php } ?>
          </select>
          <select name="area" class="form-control mt-3" required>
            <option value="">Area solicitante</option>
            <?php
            foreach (getAllAreas() as $ar) { ?>
              <option value="<?= $ar['0'] ?>"><?= $ar['1'] ?> </option>
            <?php } ?>
          </select>
          <select name="periodo" class="form-control mt-3" required>
            <option value="">Periodo</option>
            <?php
            foreach (getAllPeriodos() as $pe) { ?>
              <option value="<?= $pe['0'] ?>"><?= $pe['1'] ?> </option>
            <?php } ?>
          </select>
          <select name="estatus" class="form-control mt-3" required>
            <option value="">Estatus</option>
            <?php
            foreach (getAllEstatus() as $e) { ?>
              <option value="<?= $e['0'] ?>"><?= $e['1'] ?> </option>
            <?php } ?>
            <input type="text" name="f_inic" class="form-control mt-3" placeholder="Ingrese la fecha de inicio YYYY/MM/DD">
            <input type="text" name="dias_est" class="form-control mt-3" placeholder="Ingrese los días estimados">
        
            <input type="submit" name="guardar_proyecto" class="btn btn-success btn-block mt-3" value="Guardar Proyecto">
        </div>
      </form>
    </div>
  </div>
  <div class="row">
    <table class="table ml-3 mr-3 table-bordered bg-white mt-1 text-center">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre proyecto</th>
          <th>Descripcion proyecto</th>
          <th>Responsable</th>
          <th>Area</th>
          <th>Periodo</th>
          <th>Estatus</th>
          <th>Fecha de inicio</th>
          <th>Dias estimados</th>
          <th>Dias reales</th>
          <th>Fecha fin</th>
          <th>Accion</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach (getAllProyectos() as $p) { ?>
          <tr>
            <td><?= $p['0'] ?></td>
            <td><?= $p['1'] ?></td>
            <td><?= $p['2'] ?></td>
            <td><?= $p['3'] ?></td>
            <td><?= $p['4'] ?></td>
            <td><?= $p['5'] ?></td>
            <td><?= $p['6'] ?></td>
            <td><?= $p['7']->format('Y-m-d') ?></td>
            <td><?= $p['8'] ?></td>
            <td><?= $p['9'] == 0 ? 'NA' :  $p['9'] ?></td>
            <td><?= $p['10']->format('Y-m-d') == '1900-01-01' ? 'NA' : $p['10']->format('Y-m-d') ?></td>
            <td>
              <button data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({
              id:'<?= $p['0'] ?>',
              nombre:'<?= $p['1'] ?>',
              desc:'<?= $p['2'] ?>',
              responsable:'<?= $p['11'] ?>',
              area:'<?= $p['12'] ?>',
              periodo:'<?= $p['13'] ?>',
              estatus:'<?= $p['14'] ?>',
              f_inic:'<?= $p['7']->format('Y-m-d') ?>',
              dias_est:'<?= $p['8'] ?>',
              dias_real:'<?= $p['9'] ?>',
              f_fin:'<?= $p['10']->format('Y-m-d') ?>'})">
                <i class="fas fa-marker"></i>
              </button>
              <a href="./database/proyectos/eliminar_proyecto.php?id=<?= $p['0'] ?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/proyectos/actualizar_proyecto.php" method="POST">
          <div class="form-group">
            <input class="form-control" name="id" placeholder="Ingrese id" id="inputSemanaId" type="text" readonly>
            <input type="text" name="nombre" class="form-control mt-3" id="nombre" placeholder="Ingrese el nombre del proyecto que desea registrar">
            <input type="text" name="desc" id="desc" class="form-control mt-3" placeholder="Ingrese una breve descripción">
            <select name="responsable" id="responsable" class="form-control mt-3" required>
              <option value="">Responsable(s) del proyecto</option>
              <?php
              foreach (getAllUsuarios() as $u) { ?>
                <option value="<?= $u['0'] ?>"><?= $u['1'] ?> </option>
              <?php } ?>
            </select>
            <select name="area" id="area" class="form-control mt-3" required>
              <option value="">Area solicitante</option>
              <?php
              foreach (getAllAreas() as $ar) { ?>
                <option value="<?= $ar['0'] ?>"><?= $ar['1'] ?> </option>
              <?php } ?>
            </select>
            <select name="periodo" id="periodo" class="form-control mt-3" required>
              <option value="">Periodo</option>
              <?php

              foreach (getAllPeriodos() as $pe) { ?>

                <option value="<?= $pe['0'] ?>"><?= $pe['1'] ?> </option>


              <?php } ?>
            </select>
            <select name="estatus" id="estatus" class="form-control mt-3" onchange="checkIfcomplete(this)" required>
              <option value="">Estatus</option>
              <?php

              foreach (getAllEstatus() as $e) { ?>

                <option value="<?= $e['0'] ?>"><?= $e['1'] ?> </option>


              <?php } ?>
              <input type="text" name="f_inic" id="f_inic" class="form-control mt-3" placeholder="Ingrese la fecha de inicio YYYY/MM/DD">
              <input type="text" name="dias_est" id="dias_est" class="form-control mt-3" placeholder="Ingrese los días estimados">
              <input type="text" name="dias_real" id="dias_real" class="form-control mt-3" placeholder="Ingrese los días reales">
              <input type="text" name="f_fin" id="f_fin" class="form-control mt-3"  placeholder="Ingrese la fecha de fin YYYY/MM/DD">




          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
  function days_between(date1, date2) {

    // The number of milliseconds in one day
    const ONE_DAY = 1000 * 60 * 60 * 24;

    // Calculate the difference in milliseconds
    const differenceMs = Math.abs(date1 - date2);

    // Convert back to days and return
    return Math.round(differenceMs / ONE_DAY);

  }

  function checkIfcomplete(e) {
    const dias_real = document.getElementById('dias_real');
    const f_fin = document.getElementById('f_fin');
    let sel = e;
    let text = sel.options[sel.selectedIndex].text;
    let f_inic = document.getElementById('f_inic').value;
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();
    let newdate = year + "-" + month + "-" + day;
    if (text == 'Completado') {
     
      const inicio = new Date(newdate);
      const today = new Date(f_inic);
      dias_real.value = days_between(inicio,today);
      f_fin.value = newdate;
    }else{
        dias_real.value = '';
        f_fin.value = '';
    }

  }

  function passData(data) {
    console.log(data);
    let inputID = document.getElementById('inputSemanaId');
    let nombre = document.getElementById('nombre');
    let desc = document.getElementById('desc');
    let responsable = document.getElementById('responsable');
    let area = document.getElementById('area');
    let periodo = document.getElementById('periodo');
    let estatus = document.getElementById('estatus');
    let f_inic = document.getElementById('f_inic');
    let fias_est = document.getElementById('dias_est');
    let dias_real = document.getElementById('dias_real');
    let f_fin = document.getElementById('f_fin');
    inputID.value = data.id;
    nombre.value = data.nombre;
    desc.value = data.desc;
    responsable.value = data.responsable;
    area.value = data.area;
    periodo.value = data.periodo;
    estatus.value = data.estatus;
    f_inic.value = data.f_inic;
    dias_est.value = data.dias_est;
    dias_real.value = data.dias_real == 0 ? '' : date.dias_real;
    f_fin.value = data.f_fin == '1900-01-01' ? '':data.f_fin;


  }
</script>