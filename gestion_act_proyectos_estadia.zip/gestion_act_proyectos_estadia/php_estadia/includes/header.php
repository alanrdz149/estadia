<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Universidad Tecnologica de Aguascalientes</title>
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <!-- BOOTSTRAP 4 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  <!-- FONT AWESOEM -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <style>
    /* Works on Firefox */
    * {
      scrollbar-width: thin;
      scrollbar-color: #111 white;
    }

    /* Works on Chrome, Edge, and Safari */
    *::-webkit-scrollbar {
      width: 12px;
    }

    *::-webkit-scrollbar-track {
      background: white;
    }

    *::-webkit-scrollbar-thumb {
      background-color: #111;
      border-radius: 20px;
      border: 3px solid white;
    }

    body {
      font-family: "Lato", sans-serif;
      background-image: url('./assets/background.jpg');
      background-attachment: fixed;
    }

    .sidebar {
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    .sidebar a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: block;
      transition: 0.3s;
    }

    .sidebar a:hover {
      color: #f1f1f1;
    }

    .sidebar .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }

    .openbtn {
      font-size: 20px;
      cursor: pointer;
      background-color: #111;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 10%;
    }

    .openbtn:hover {
      background-color: #444;
    }

    #main {
      transition: margin-left .5s;
      padding: 16px;
    }

    /* On smaller screens, where height is less than 450px, change the style of the sidenav (less padding and a smaller font size) */
    @media screen and (max-height: 450px) {
      .sidebar {
        padding-top: 15px;
      }

      .sidebar a {
        font-size: 18px;
      }
    }
  </style>
</head>

<body class="body">




  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <ul class="navbar-nav me-auto mb-2 ml-4">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./actividadesUsuario.php">Actividades de usuario</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./proyecto.php">Proyectos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./metrica.php">Metrica</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./area.php">Area</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./estatus.php">Estatus</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./periodo.php">Periodo</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./semana.php">Semana</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./actividades.php">Actividad</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./generar_reporte.php">Generar Reporte de Actividades</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./reporte_proyectos.php">Generar Reporte de Proyecto</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./reporte_general_proyectos.php">Reporte General de Proyectos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./reporte_general_actividades.php">Reporte General de Actividades</a>
      </li>
    </ul>
  </div>

  <div id="main">
    <button class="openbtn" onclick="openNav()">☰</button>
  </div>

  <script>
    function openNav() {
      document.getElementById("mySidebar").style.width = "250px";
      document.getElementById("main").style.marginLeft = "250px";
    }

    function closeNav() {
      document.getElementById("mySidebar").style.width = "0";
      document.getElementById("main").style.marginLeft = "0";
    }
  </script>