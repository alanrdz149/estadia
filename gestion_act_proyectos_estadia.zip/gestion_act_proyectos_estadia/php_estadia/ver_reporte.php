<?php include('./database/db.php'); ?>
<?php include('includes/header.php'); ?> 
<?php include('./database/actividadesUsuario/mostrar_reporte.php'); ?> 
<main class="container p-4">
  <div class="row">

        
      <div id="chartContainer" class="container w-75 "></div>
  </div>
</main>

<?php include('includes/footer.php'); ?>

<script>
window.onload = function () {
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,

	title:{
		text: "Reporte"
	},
	axisY: {
		title: "Actividades",
		includeZero: true
	},
	legend: {
		cursor:"pointer",
		itemclick : toggleDataSeries
	},
	toolTip: {
		shared: true,
		content: toolTipFormatter
	},
	data: [{
		type: "column",
		showInLegend: true,
		name: "Estimadas",
		color: "#17ca3d",
		dataPoints: [
			<?php
               
               foreach(getActivitiesByUserAndWeek($_GET['usuario'],$_GET['semana']) as $m ){?>
			{ y: <?=$m['1']?>, label: "<?=$m['2']?>" },

             <?php }?>
			
	
		]
	},

	{
		type: "column",
		showInLegend: true,
		name: "Reales",
		color: "#00afff",
		dataPoints: [
			<?php
               
               foreach(getActivitiesByUserAndWeek($_GET['usuario'],$_GET['semana']) as $m ){?>
			{ y: <?=$m['0']?>, label: "<?=$m['2']?>" },

             <?php }?>
			
	
		]
	}]
});
chart.render();

function toolTipFormatter(e) {
	var str = "";
	var total = 0 ;
	var str3;
	var str2 ;
	for (var i = 0; i < e.entries.length; i++){
		var str1 = "<span style= \"color:"+e.entries[i].dataSeries.color + "\">" + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong> <br/>" ;
		total = e.entries[i].dataPoint.y + total;
		str = str.concat(str1);
	}
	str2 = "<strong>" + e.entries[0].dataPoint.label + "</strong> <br/>";
	return (str2.concat(str));
}

function toggleDataSeries(e) {
	if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else {
		e.dataSeries.visible = true;
	}
	chart.render();
}

}
 

</script>
