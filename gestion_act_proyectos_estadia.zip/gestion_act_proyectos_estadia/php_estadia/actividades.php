<?php include('./database/db.php'); ?>
<?php include('includes/header.php'); ?>
<?php include('./database/metrica/obtener_metrica.php'); ?>
<?php include('./database/actividades/mostrar_actividades.php'); ?>

<main class="container p-4">

  <?php if (isset($_SESSION['message'])) { ?>
    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message'] ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php session_unset();
  } ?>

  <div class="row">
    <div class="card card-body">
      <h1>Actividad</h1>
      <form action="./database/actividades/guardar_actividad.php" method="POST">
        <div class="form-group">
          <input type="text" name="actividad" class="form-control" placeholder="Ingrese la actividad" autofocus>

          <select name="metrica" class="form-control mt-3" required>
            <option value="">Seleccione una metrica</option>
            <?php

            foreach (getAllMetricas() as $m) { ?>

              <option value="<?= $m['0'] ?>"><?= $m['1'] ?> </option>


            <?php } ?>
          </select>
          <input type="submit" name="guardar_actividad" class="btn btn-success btn-block mt-3" value="Guardar Actividad">

        </div>
      </form>
    </div>

  </div>


  <div class="row">
    <table class="table table-bordered bg-white mt-5 text-center">
      <thead>
        <tr>
          <th>ID</th>

          <th>Actividad</th>
          <th>Metrica</th>
          <th>Acción</th>
        </tr>
      </thead>
      <tbody>


        <?php

        foreach (getAllActividades() as $a) { ?>

          <tr>
            <td><?= $a['0'] ?></td>
            <td><?= $a['1'] ?></td>
            <td><?= $a['4'] ?></td>

            <td>
              <button  data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({name:'<?= $a['1'] ?>',id:'<?= $a['0'] ?>'})">
                <i class="fas fa-marker"></i>
        </button>
              <a href="./database/actividades/eliminar_actividad.php?id=<?= $a['0'] ?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>

        <?php } ?>


      </tbody>
    </table>

  </div>
</main>

<!-- Modal -->
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/actividades/actualizar_actividad.php" method="POST">
          <div class="form-group">

            <input class="form-control" name="id" placeholder="Ingrese la actividad" id="inputActividadID" type="text" readonly>
            <input class="form-control mt-3" name="actividad" id="inputActividad" value="Modificar" type="text">
            <select name="metrica" class="form-control mt-3" required>
            <option value="">Seleccione una metrica</option>
            <?php

            foreach (getAllMetricas() as $m) { ?>

              <option value="<?= $m['0'] ?>"><?= $m['1'] ?> </option>


            <?php } ?>
          </select>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
  function passData(data) {
    let inputID = document.getElementById('inputActividadID');

    let input = document.getElementById('inputActividad');
    input.value = data.name;
    inputID.value = data.id;
    
  }
</script>