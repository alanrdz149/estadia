<?php include('./database/db.php'); ?>
<?php include('./database/estatus/mostrar_estatus.php'); ?>
<?php include('includes/header.php'); ?>
<main class="container p-4" >
<?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php session_unset(); } ?>
  <div class="row">
    <div class="card card-body">
        <h1 >Estatus</h1>
        <form action="./database/estatus/guardar_estatus.php" method="POST">
            <div class="form-group">
                <input type="text" name="estatus" class="form-control" placeholder="Ingrese el estatus que desea registrar" autofocus>
                <input type="submit" name="guardar_estatus" class="btn btn-success btn-block mt-3" value="Guardar Estatus">
    
            </div>
        </form>
    </div>

</div>
<div class="row">
<table class="table table-bordered bg-white mt-5 text-center">
        <thead>
          <tr>
          <th>ID</th>

            <th>Estatus</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>


        <?php
               
               foreach(getAllEstatus() as $e ){?>

            <tr>
              <td><?=$e['0']?></td>
              <td><?=$e['1']?></td>
               

              <td>
              <button  data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({id:'<?= $e['0'] ?>',estatus:'<?= $e['1']?>'})">
                  <i class="fas fa-marker"></i>
                 </button>
                <a href="./database/estatus/eliminar_estatus.php?id=<?=$e['0']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>

             <?php }?>
        
        
        </tbody>
      </table>

</div>
</main>

<!-- Modal --> 
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/estatus/actualizar_estatus.php" method="POST">
          <div class="form-group">
          <input class="form-control" name="id" placeholder="Ingrese id" id="inputId" type="text" readonly>
          <input class="form-control mt-3" name="estatus" placeholder="ingrese la semna" id="inputestatus" type="text">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>


<script>
  function passData(data) {
    console.log(data);
    let inputID = document.getElementById('inputId');
    let estatus = document.getElementById('inputestatus');
    inputID.value = data.id;
    estatus.value = data.estatus;
  }
</script>