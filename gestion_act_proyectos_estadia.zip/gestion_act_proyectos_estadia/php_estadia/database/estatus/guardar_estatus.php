<?php include('../db.php'); 
session_start();
$estatus=$_POST["estatus"];
$query="INSERT INTO estatus(estatus) VALUES('$estatus')";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../estatus.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../estatus.php');
}
?>