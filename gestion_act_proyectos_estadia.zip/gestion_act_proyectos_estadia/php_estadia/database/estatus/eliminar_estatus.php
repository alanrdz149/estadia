<?php
include('../db.php'); 
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM estatus WHERE id_estatus = $id";
  $res=sqlsrv_query($conn,$query);
  if(!$res) {
    echo $res; 
   }else{
    $_SESSION['message'] = 'Actividad eliminada con exito';
    $_SESSION['message_type'] = 'success';
    header('Location: ./../../estatus.php');
   }

}

?>
