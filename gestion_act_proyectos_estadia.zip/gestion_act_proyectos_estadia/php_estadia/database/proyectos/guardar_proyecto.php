<?php include('../db.php'); 
$nombre=$_POST["nombre"];
$desc=$_POST["desc"];
$responsable=$_POST["responsable"];
$area=$_POST["area"];
$periodo=$_POST["periodo"];
$estatus=$_POST["estatus"];
$f_inic=$_POST["f_inic"];
$dias_est=$_POST["dias_est"];
$dias_real='';
$f_fin='';
$query="insert into proyectos(nombre, descripcion, usuario_id, area_id, periodos_id, estatus_id, fecha_inicio, dias_estimados, dias_reales, fecha_fin)
values('$nombre','$desc','$responsable','$area','$periodo','$estatus','$f_inic','$dias_est','$dias_real','$f_fin');";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../proyecto.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../proyecto.php');
}
?>
