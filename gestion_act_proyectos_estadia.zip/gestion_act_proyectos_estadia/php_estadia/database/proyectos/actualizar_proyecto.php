<?php include('../db.php'); 
$id = $_POST['id'];
$nombre=$_POST["nombre"];
$desc=$_POST["desc"];
$responsable=$_POST["responsable"];
$area=$_POST["area"];
$periodo=$_POST["periodo"];
$estatus=$_POST["estatus"];
$f_inic=$_POST["f_inic"];
$dias_est=$_POST["dias_est"];
$dias_real=$_POST["dias_real"];
$f_fin=$_POST["f_fin"];
$query="UPDATE proyectos set nombre = '$nombre', descripcion = '$desc', usuario_id = $responsable, area_id = $area, periodos_id = $periodo, estatus_id = $estatus, fecha_inicio = '$f_inic', dias_estimados = $dias_est, dias_reales = $dias_real, fecha_fin = '$f_fin' WHERE proyecto_id = $id";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos actualizados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../proyecto.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../proyecto.php');
}
?>
