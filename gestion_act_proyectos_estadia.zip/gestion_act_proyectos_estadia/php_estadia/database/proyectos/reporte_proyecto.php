<?php

function getReporteProyectos()
{
    $id = $_GET['proyecto'];
    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = "select proyecto_id, nombre, descripcion, nombre_usuario, area, periodo, estatus, fecha_inicio, dias_estimados, dias_reales, fecha_fin, id_usuario, id_areas, id_periodos, id_estatus from proyectos p inner join usuarios u on (p.usuario_id=u.id_usuario) inner join areas a on (p.area_id=a.id_areas) inner join periodos pe on (p.periodos_id=pe.id_periodos) inner join estatus e on (p.estatus_id=e.id_estatus) WHERE proyecto_id = $id";
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
    // you need SQLSRV_FETCH_NUMERIC for your result, but i prefere to use SQLSRV_FETCH_ASSOC
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);
    return $res;
}

function getdaysBetween($date1){
    $now = time();
    $your_date = strtotime($date1);
    $datediff = $now - $your_date;

    return round($datediff / (60 * 60 * 24));

}


function getProyectosByPeriodo($periodo)
{
    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = "select p.nombre, u.nombre_usuario,e.estatus from proyectos as p inner join estatus as e on (e.id_estatus = p.estatus_id) inner join usuarios as u on (u.id_usuario = p.usuario_id) where periodos_id = $periodo;";
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
    // you need SQLSRV_FETCH_NUMERIC for your result, but i prefere to use SQLSRV_FETCH_ASSOC
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);
    return $res;
}

?>