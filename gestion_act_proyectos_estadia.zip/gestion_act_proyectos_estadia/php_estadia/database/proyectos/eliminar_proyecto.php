<?php
include('../db.php'); 
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM proyectos WHERE proyecto_id = $id";
  $res=sqlsrv_query($conn,$query);
  echo $query;
  echo $res;
  if(!$res) {
    echo $res; 
   }else{
     echo $res;
    $_SESSION['message'] = 'Proyecto eliminada con exito';
    $_SESSION['message_type'] = 'success';
    header('Location: ./../../proyecto.php');
   }

}

?>