<?php  
/* Specify the server and connection string attributes. */  
session_start();
$serverName = "(local)";  
$connectionInfo = array( "Database"=>"registrosSistemas");  
  
/* Connect using Windows Authentication. */  
$conn = sqlsrv_connect( $serverName, $connectionInfo);  
if( $conn === false )  
{  
     echo "Unable to connect.</br>";  
     die( print_r( sqlsrv_errors(), true));  
}  