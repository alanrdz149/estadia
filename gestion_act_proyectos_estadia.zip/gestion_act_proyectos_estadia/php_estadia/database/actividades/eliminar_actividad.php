<?php
include('../db.php'); 
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM actividades WHERE id_actividad = $id";
  $res=sqlsrv_query($conn,$query);
  if(!$res) {
    echo $res; 
   }

  $_SESSION['message'] = 'Actividad eliminada con exito';
  $_SESSION['message_type'] = 'success';
  header('Location: ./../../actividades.php');
}

?>
