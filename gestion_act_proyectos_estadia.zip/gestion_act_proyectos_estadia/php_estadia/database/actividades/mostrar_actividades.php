<?php

function getAllActividades()
{
    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = 'select * from actividades a inner join metricas m on (a.metrica_id = m.id_metrica)';
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
    // you need SQLSRV_FETCH_NUMERIC for your result, but i prefere to use SQLSRV_FETCH_ASSOC
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);
    return $res;
}
function getActividadesReporte($id)
{
    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = "select  id_actUsr, nombre_usuario, actividad, act_estimadas, act_reales from activiades_usuarios au inner join usuarios u on au.usuarios_id=u.id_usuario inner join actividades a on au.actividades_id= a.id_actividad inner join semanas s on au.semanas_id= s.semana_id inner join periodos p on s.periodo_id=p.id_periodos where s.periodo_id=$id";
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
    // you need SQLSRV_FETCH_NUMERIC for your result, but i prefere to use SQLSRV_FETCH_ASSOC
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);
    return $res;
}



?>