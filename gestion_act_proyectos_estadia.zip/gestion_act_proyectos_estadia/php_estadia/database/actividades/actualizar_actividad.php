<?php
include('../db.php'); 
$id=$_POST["id"];
$actividad=$_POST["actividad"];
$metrica=$_POST["metrica"];
$query=" UPDATE actividades SET actividad = '$actividad', metrica_id = $metrica WHERE id_actividad = $id";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos actualizados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../actividades.php');
}
else{
    $_SESSION['message'] = 'error al actualizae los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../actividades.php');
}


?>
