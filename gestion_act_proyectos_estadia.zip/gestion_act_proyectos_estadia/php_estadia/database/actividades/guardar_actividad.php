<?php include('../db.php'); 
$actividad=$_POST["actividad"];
$metrica=$_POST["metrica"];
$query="insert into actividades(actividad, metrica_id) values('$actividad', $metrica);";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../actividades.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../actividades.php');
}
?>
