<?php include('../db.php'); 
session_start();
$metrica=$_POST["metrica"];
$query="INSERT INTO metricas(metrica) VALUES('$metrica')";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../metrica.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../metrica.php');
}
?>