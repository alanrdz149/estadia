<?php
//aun no cambiaba nada de los campos pq primeor andaba viendo si jalaba el modal
include('../db.php'); 
$id=$_POST["id"];
$metrica=$_POST["metrica"];
$query=" UPDATE metricas SET  metrica = '$metrica' WHERE id_metrica = $id";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos actualizados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../metrica.php');
}
else{
    $_SESSION['message'] = 'error al actualizae los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../metrica.php');
}


?>


