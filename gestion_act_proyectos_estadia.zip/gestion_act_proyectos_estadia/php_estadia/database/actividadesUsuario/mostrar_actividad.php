<?php

function getAllActividadesUsuario()
{
    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = 'select id_actUsr, actividad, nombre_usuario, act_estimadas, act_reales, semana,id_actividad, id_usuario from activiades_usuarios au inner join actividades a on (au.actividades_id = a.id_actividad) inner join usuarios u on (au.usuarios_id = u.id_usuario) inner join semanas s on (au.semanas_id = s.semana_id)';
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
    // you need SQLSRV_FETCH_NUMERIC for your result, but i prefere to use SQLSRV_FETCH_ASSOC
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);
    return $res;
}


?>