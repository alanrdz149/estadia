<?php
function getActivitiesByUserAndWeek($usuario,$semana)
{

    /* Specify the server and connection string attributes. */  
    $serverName = "(local)";  
    $connectionInfo = array( "Database"=>"registrosSistemas");  
  
    /* Connect using Windows Authentication. */  
    $conn = sqlsrv_connect( $serverName, $connectionInfo);
    $select = "select act_estimadas, act_reales, a.actividad from activiades_usuarios au inner join actividades a on au.actividades_id = a.id_actividad WHERE usuarios_id = $usuario and semanas_id = $semana";
    $query = sqlsrv_query($conn, $select);
    if ($query === false) {
        echo "Error la base";
        return "Error al conectar con la base de datos";
    }
    $res = [];
    while( $row = sqlsrv_fetch_array($query, SQLSRV_FETCH_NUMERIC) ) {
        $res[] = $row;
    }
    
    sqlsrv_free_stmt($query);

    return $res;
}


?>