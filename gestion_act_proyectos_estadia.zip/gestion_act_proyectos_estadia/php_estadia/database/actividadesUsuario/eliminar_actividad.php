<?php
include('../db.php'); 
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM activiades_usuarios WHERE id_actUsr = $id";
  $res=sqlsrv_query($conn,$query);
  if(!$res) {
    echo $res; 
   }else{
    $_SESSION['message'] = 'Actividad eliminada con exito';
    $_SESSION['message_type'] = 'success';
    header('Location: ./../../actividadesUsuario.php');
   }

}

?>
