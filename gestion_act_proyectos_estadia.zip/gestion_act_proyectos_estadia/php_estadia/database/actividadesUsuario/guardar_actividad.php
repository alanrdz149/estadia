<?php include('../db.php'); 
$actividades=$_POST["actividades"];
$act_estimadas=$_POST["act_estimadas"];
$act_reales=$_POST["act_reales"];
$usuario=$_POST["usuario"];
$semana=$_POST["semana"];
$query="insert into activiades_usuarios(actividades_id, act_estimadas, act_reales, usuarios_id, semanas_id)
values('$actividades','$act_estimadas','$act_reales','$usuario','$semana');";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../actividadesUsuario.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../actividadesUsuario.php');
}
?>
