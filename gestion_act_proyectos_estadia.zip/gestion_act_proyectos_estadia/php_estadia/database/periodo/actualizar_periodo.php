<?php
//aun no cambiaba nada de los campos pq primeor andaba viendo si jalaba el modal
include('../db.php'); 
$id=$_POST["id"];
$periodo=$_POST["periodo"];
$query=" UPDATE periodos SET  periodo = '$periodo' WHERE id_periodos = $id";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos actualizados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../periodo.php');
}
else{
    $_SESSION['message'] = 'error al actualizae los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../periodo.php');
}


?>


