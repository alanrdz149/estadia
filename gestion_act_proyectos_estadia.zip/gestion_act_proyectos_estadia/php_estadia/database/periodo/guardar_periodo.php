<?php include('../db.php'); 
session_start();
$periodo=$_POST["periodo"];
$query="INSERT INTO periodos(periodo) VALUES('$periodo')";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../periodo.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../periodo.php');
}
?>