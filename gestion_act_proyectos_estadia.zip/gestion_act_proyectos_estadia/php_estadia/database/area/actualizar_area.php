<?php

include('../db.php'); 
$id=$_POST["id"];
$area=$_POST["area"];
$query=" UPDATE areas SET  area = '$area' WHERE id_areas = $id";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos actualizados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../area.php');
}
else{
    $_SESSION['message'] = 'error al actualizar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../area.php');
}


?>


