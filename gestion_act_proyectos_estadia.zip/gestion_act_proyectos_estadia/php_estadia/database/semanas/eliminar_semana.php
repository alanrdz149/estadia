<?php
include('../db.php'); 
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = "DELETE FROM semanas WHERE semana_id = $id";
  $res=sqlsrv_query($conn,$query);
  echo $query;
  echo $res;
  if(!$res) {
    echo $res; 
   }else{
     echo $res;
    $_SESSION['message'] = 'Semana eliminada con exito';
    $_SESSION['message_type'] = 'success';
    header('Location: ./../../semana.php');
   }

}

?>