<?php include('../db.php'); 
session_start();
$semana=$_POST["semana"];
$periodo=$_POST["periodo"];
$query="insert into semanas(semana, periodo_id) values('$semana', $periodo)";
$res=sqlsrv_prepare($conn,$query);

if(sqlsrv_execute($res)){
    $_SESSION['message'] = 'Datos insertados correctamente';
    $_SESSION['message_type'] = 'success';
    header('Location: ../../semana.php');
}
else{
    $_SESSION['message'] = 'error al insertar los datos';
    $_SESSION['message_type'] = 'warning';
    header('Location: ../../semana.php');
}
?>