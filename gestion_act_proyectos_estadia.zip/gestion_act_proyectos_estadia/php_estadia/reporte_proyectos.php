<?php include('includes/header.php'); ?> 
<?php include('./database/proyectos/mostrar_proyectos.php'); ?>

<main class="container p-4">
  <div class="row">
  <div class="card card-body">
      <h1>Generar Reporte</h1>
      <form action="./ver_reporte_proyecto.php" method="GET">
        <div class="form-group">
        <select name="proyecto" class="form-control " required>
                    <option value="">Seleccione un proyecto</option>
                    <?php
                    foreach(getAllProyectos() as $u ){?>
                    <option value="<?=$u['0']?>"><?=$u['1'] ?> </option>
                  <?php }?>
                </select>
    
        <input type="submit" class="btn btn-success btn-block mt-3" value="Generar Reporte">

        </div>
      </form>
    </div>

        
  </div>
</main>

<?php include('includes/footer.php'); ?>

