<?php include('./database/db.php'); ?>
<?php include('includes/header.php'); ?>
<?php include('./database/semanas/mostrar_semanas.php'); ?>
<?php include('./database/periodo/obtener_periodo.php'); ?>
<main class="container p-4">

  <?php if (isset($_SESSION['message'])) { ?>
    <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message'] ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php session_unset();
  } ?>

  <div class="row">
    <div class="card card-body">
      <h1>Semana</h1>
      <form action="./database/semanas/guardar_semana.php" method="POST">
        <div class="form-group">
          <input type="text" name="semana" class="form-control" placeholder="Ingrese la semana que desea registrar" autofocus>
          <select name="periodo" class="form-control mt-3" required>
            <option value="">Seleccione una periodo</option>
            <?php

            foreach (getAllPeriodos() as $p) { ?>

              <option value="<?= $p['0'] ?>"><?= $p['1'] ?> </option>


            <?php } ?>
          </select>

          <input type="submit" name="guardar_semana" class="btn btn-success btn-block mt-3" value="Guardar Semana">

        </div>
      </form>
    </div>

  </div>
  <div class="row">
    <table class="table table-bordered bg-white mt-5 text-center">
      <thead>
        <tr>
          <th>ID</th>

          <th>Semana</th>
          <th>Periodo</th>
          <th>Acción</th>
        </tr>
      </thead>
      <tbody>


        <?php

        foreach (getAllSemanas() as $a) { ?>

          <tr>
            <td><?= $a['0'] ?></td>
            <td><?= $a['1'] ?></td>
            <td><?= $a['2'] ?></td>

            <td>
              <button data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({id:'<?= $a['0'] ?>',semana:'<?= $a['1'] ?>',id_periodo:'<?= $a['3'] ?>'})">
                <i class="fas fa-marker"></i>
              </button>
              <a href="./database/semanas/eliminar_semana.php?id=<?= $a['0'] ?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>

        <?php } ?>


      </tbody>
    </table>

  </div>
</main>




<!-- Modal -->
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/semanas/actualizar_semana.php" method="POST">
          <div class="form-group">
            <input class="form-control" name="id" placeholder="Ingrese id" id="inputSemanaId" type="text" readonly>
            <input class="form-control mt-3" name="semana" placeholder="ingrese la semna" id="inputSemana" type="number">
            <select name="periodo_id" id="inputPeriodo" class="form-control mt-3" required>
              <option value="">Seleccione una periodo</option>
              <?php

              foreach (getAllPeriodos() as $p) { ?>

                <option value="<?= $p['0'] ?>"><?= $p['1'] ?> </option>


              <?php } ?>
            </select>

          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
  function passData(data) {
    console.log(data);
    let inputID = document.getElementById('inputSemanaId');
    let semana = document.getElementById('inputSemana');
    let periodo = document.getElementById('inputPeriodo');
    inputID.value = data.id;
    semana.value = data.semana;
    periodo.value = data.id_periodo;
  }
</script>