<?php include('includes/header.php'); ?>
<?php include('database/actividades/mostrar_actividades.php'); ?>
<main class="container p-4">
  <div class="row">
    <div class="card card-body">
      <h1>Reporte general de actividades</h1>
    </div>
  </div>

  <div class="row mt-3">
    <div class="card card-body">
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Usuario</th>
            <th>Actividad</th>
            <th>Actividades Estimadas</th>
            <th>Actividades Reales</th>
          </tr>
        </thead>
        <tbody>
          <?php
          foreach (getActividadesReporte($_GET['proyecto']) as $p) { ?>
            <tr>
              <td><?=$p['1']?></td>
              <td><?=$p['2']?></td>
              <td><?=$p['3']?></td>
              <td><?=$p['4']?></td>
           
            </tr>

          <?php } ?>

        </tbody>
      </table>
    </div>
  </div>
</main>

<?php include('includes/footer.php'); ?>