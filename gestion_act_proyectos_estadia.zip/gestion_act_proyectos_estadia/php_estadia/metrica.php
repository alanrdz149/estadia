<?php include('./database/db.php'); ?>
<?php include('./database/metrica/mostrar_metricas.php'); ?>
<?php include('includes/header.php'); ?>
<main class="container p-4" >
<?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php session_unset(); } ?>
  <div class="row">
    <div class="card card-body">
        <h1 >Metricas</h1>
        <form action="./database/metrica/guardar_metrica.php" method="POST">
            <div class="form-group">
                <input type="text" name="metrica" class="form-control" placeholder="Ingrese la metrica que desea registrar" autofocus>
                <input type="submit" name="guardar_metrica" class="btn btn-success btn-block mt-3" value="Guardar Metrica">
    
            </div>
        </form>
    </div>

</div>
<div class="row">
<table class="table table-bordered bg-white mt-5 text-center">
        <thead>
          <tr>
          <th>ID</th>

            <th>Metrica</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>


        <?php
               
               foreach(getAllMetrics() as $m ){?>

            <tr>
              <td><?=$m['0']?></td>
              <td><?=$m['1']?></td>
               

              <td>
              <button  data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({id:'<?= $m['0'] ?>',metrica:'<?= $m['1']?>'})">
                  <i class="fas fa-marker"></i>
                 </button>
                <a href="./database/metrica/eliminar_metrica.php?id=<?= $m['0']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>

             <?php }?>
        
        
        </tbody>
      </table>

</div>
</main>

<!-- Modal --> 
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/metrica/actualizar_metrica.php" method="POST">
          <div class="form-group">
          <input class="form-control" name="id" placeholder="Ingrese id" id="inputId" type="text" readonly>
          <input class="form-control mt-3" name="metrica" placeholder="ingrese la semna" id="inputmetrica" type="text">
         
                 
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>


<script>
  function passData(data) {
    console.log(data);
    let inputID = document.getElementById('inputId');
    let metrica = document.getElementById('inputmetrica');
    inputID.value = data.id;
    metrica.value = data.metrica;
  }
</script>