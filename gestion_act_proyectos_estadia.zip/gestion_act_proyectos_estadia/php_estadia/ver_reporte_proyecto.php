<?php include('./database/db.php'); ?>
<?php include('includes/header.php'); ?>
<?php include('database/proyectos/reporte_proyecto.php'); ?>

<main class="container p-4">

    <?php if (isset($_SESSION['message'])) { ?>
        <div class="alert alert-<?= $_SESSION['message_type'] ?> alert-dismissible fade show" role="alert">
            <?= $_SESSION['message'] ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php session_unset();
    } ?>

    <div class="row">
        <div class="card card-body">
            <?php
            foreach (getReporteProyectos() as $m) { ?>

                <h1>Informacion Sobre <?= $m['1'] ?></h1>


            <?php } ?>

        </div>
    </div>
        <div class="row mt-5">
        <div class="card card-body">
            <?php
            foreach (getReporteProyectos() as $m) { ?>


                <p class="h2">Nombre del Proyecto: <span class="h2 font-italic"><?= $m['1'] ?></span> </p>
                <p class="h2">Estatus: <span class="h2 font-italic"><?= $m['6'] ?></span> </p>
                <p class="h2">Fecha de Inicio: <span class="h2 font-italic"><?= $m['7']->format('Y-m-d') ?></span> </p>
                <p class="h2">El proyecto inició hace <span class="h2 font-italic"><?=getdaysBetween($m['7']->format('Y-m-d'))  ?> dias</span> </p>
                <?=  $m['6'] == 'Completado' ? "<p class='h2'>El proyecto fue completado el día: <span class='h2 font-italic'>".$m['10']->format('Y-m-d')."</span> </p>"  :null ?>
                <?php } ?>

        </div>

    </div>
</main>





<?php include('includes/footer.php'); ?>

