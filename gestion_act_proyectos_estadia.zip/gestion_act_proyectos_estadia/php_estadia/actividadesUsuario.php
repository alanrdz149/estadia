<?php include('./database/db.php'); ?>
<?php include('includes/header.php'); ?>
<?php include('./database/actividadesUsuario/mostrar_actividad.php'); ?>
<?php include('./database/semanas/mostrar_semanas.php'); ?>
<?php include('./database/actividades/actividades.php'); ?>
<?php include('./database/usuarios/obtener_usuarios.php'); ?>
<main class="container p-4" >
<?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php session_unset(); } ?>
  <div class="row">
    <div class="card card-body">
        <h1 >Actividad</h1>
        <form action="./database/actividadesUsuario/guardar_actividad.php" method="POST">
            <div class="form-group">
            <select name="actividades" class="form-control mt-3" required>
                    <option value="">Seleccione una actividad</option>
                    <?php
               
                    foreach(getAllActividades() as $act ){?>

                    <option value="<?=$act['0']?>"><?=$act['1'] ?> </option>


                  <?php }?>
            </select>
                <input type="text" name="act_estimadas" class="form-control mt-4 mb-4" placeholder="Ingrese la cantidad de actividades planeadas" autofocus>
                <input type="text" name="act_reales" class="form-control mt-4 mb-4" placeholder="Ingrese la canridad de actividades reales" autofocus>
                <select name="usuario" class="form-control mt-3" required>
                    <option value="">Seleccione un usuario</option>
                    <?php
               
                    foreach(getAllUsuarios() as $u ){?>

                    <option value="<?=$u['0']?>"><?=$u['1'] ?> </option>


                  <?php }?>
                </select>
                <select name="semana" class="form-control mt-3" required>
                    <option value="">Seleccione una semana</option>
                    <?php
               
                    foreach(getAllSemanas() as $p ){?>
                    
                    <option value="<?=$p['0']?>">Semana <?=$p['1'] ?> - <?=$p['2'] ?> </option>


                  <?php }?>
                </select>
                <input type="submit" name="guardar_actividad" class="btn btn-success btn-block mt-3" value="Guardar Actividad">
    
            </div>
        </form>
    </div>

</div>

<div class="row">
<table class="table table-bordered bg-white mt-5 text-center">
        <thead>
          <tr>
          <th>ID</th>

            <th>Actividad</th>
            <th>Usuario</th>
            <th>Act estimadas</th>
            <th>Act. Reales</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>


        <?php
               
               foreach(getAllActividadesUsuario() as $a ){?>

            <tr>
              <td><?=$a['0']?></td>
              <td><?=$a['1']?></td>
              <td><?=$a['2']?></td>
              <td><?=$a['3']?></td>
                <td><?=$a['4']?></td>

                <td>
              <button  data-toggle="modal" data-target="#modalEdit" class="btn btn-secondary" onClick="passData({actividad:'<?= $a['6'] ?>',id:'<?= $a['0'] ?>',usuario:'<?= $a['7'] ?>',actEstimada:'<?= $a['3'] ?>',actReales:'<?= $a['4'] ?>'})">
                <i class="fas fa-marker"></i>
        </button>
              <a href="./database/actividadesUsuario/eliminar_actividad.php?id=<?= $a['0'] ?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>

        <?php } ?>
        
        
        </tbody>
      </table>

</div>
</main>

<!-- Modal --> 
<div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="./database/actividadesUsuario/actualizar_actividad.php" method="POST">
          <div class="form-group">
          <input class="form-control" name="id" placeholder="Ingrese la actividad" id="inputActividadID" type="text" readonly>
          <select name="actividad" id="inputActividad" class="form-control mt-3" required>
                    <option value="">Seleccione una actividad</option>
                    <?php
               
                    foreach(getAllActividades() as $act ){?>

                    <option value="<?=$act['0']?>"><?=$act['1'] ?> </option>


                  <?php }?>
            </select>
            <input class="form-control mt-3" name="actEstimadas" id="inputActEstimadas" type="number">
            <input class="form-control mt-3" name="actReales" id="inputActReales" type="number">
            <select name="usuario" id="inputUsuario" class="form-control mt-3" required>
              <option value="">Seleccione un Usuario</option>
              <?php
               
               foreach(getAllUsuarios() as $u ){?>

               <option value="<?=$u['0']?>"><?=$u['1'] ?> </option>


             <?php }?>
            </select>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="actualizar_actividad" class="btn btn-primary">Save changes</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
  function passData(data) {
    console.log(data);
    let inputID = document.getElementById('inputActividadID');
    let input = document.getElementById('inputActividad');
    let inputActEstimadas = document.getElementById('inputActEstimadas');
    let inputActReales = document.getElementById('inputActReales');
    let inputUsuario = document.getElementById('inputUsuario');
    input.value = data.actividad;
    inputUsuario.value = data.usuario;
    inputActEstimadas.value = data.actEstimada;
    inputActReales.value = data.actReales;
    inputID.value = data.id;
  }
</script>