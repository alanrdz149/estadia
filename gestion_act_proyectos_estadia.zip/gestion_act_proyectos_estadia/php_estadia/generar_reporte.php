<?php include('includes/header.php'); ?> 
<?php include('./database/usuarios/obtener_usuarios.php'); ?>
<?php include('./database/semanas/mostrar_semanas.php'); ?>

<main class="container p-4">
  <div class="row">
  <div class="card card-body">
      <h1>Generar Reporte</h1>
      <form action="./ver_reporte.php" method="GET">
        <div class="form-group">
        <select name="usuario" class="form-control " required>
                    <option value="">Seleccione un usuario</option>
                    <?php
                    foreach(getAllUsuarios() as $u ){?>
                    <option value="<?=$u['0']?>"><?=$u['1'] ?> </option>
                  <?php }?>
                </select>
        <select name="semana" class="form-control mt-3" required>
                    <option value="">Seleccione una semana</option>
                    <?php
                    foreach(getAllSemanas() as $p ){?>
                    <option value="<?=$p['0']?>">Semana <?=$p['1'] ?> - <?=$p['2'] ?> </option>
                  <?php }?>
                </select>
        <input type="submit" class="btn btn-success btn-block mt-3" value="Generar Reporte">

        </div>
      </form>
    </div>

        
  </div>
</main>

<?php include('includes/footer.php'); ?>

