<?php include('includes/header.php'); ?> 
<?php include('./database/periodo/obtener_periodo.php'); ?>
<main class="container p-4">
  <div class="row">
  <div class="card card-body">
      <h1>Reporte General de Actividades</h1>
      <form action="./ver_reporte_general_actividades.php" method="GET">
        <div class="form-group">
        <select name="proyecto" class="form-control " required>
                    <option value="">Seleccione un periodo</option>
                    <?php
            foreach (getAllPeriodos() as $pe) { ?>
              <option value="<?= $pe['0'] ?>"><?= $pe['1'] ?> </option>
            <?php } ?>
                </select>
    
        <input type="submit" class="btn btn-success btn-block mt-3" value="Generar Reporte">

        </div>
      </form>
    </div>

        
  </div>
</main>

<?php include('includes/footer.php'); ?>

